<!DOCTYPE >
<html lang="en">
<head>
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta charset="utf-8">
    <meta name="description" content="<?php echo $__env->yieldContent('description'); ?>">
    <meta name="keywords" content="<?php echo $__env->yieldContent('keywords'); ?>">
    <?php echo $__env->make('web.layouts.plugin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
    
    
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    
    <link rel="stylesheet" href="http://18.188.188.62/papersrc/assets/plugins/notifications/css/lobibox.min.css"/>
    <script src="http://18.188.188.62/papersrc/assets/plugins/notifications/js/notifications.min.js"></script>
    <script src="http://18.188.188.62/papersrc/assets/plugins/notifications/js/notification-custom-script.js"></script>
    

    <script type=text/javascript>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    </script>
    <style type="text/css">
        .errorClass {
            border: 1px solid red;
        }

    </style>
    <?php echo $__env->yieldContent('head'); ?>
</head>
<body class="body_color">
<?php echo $__env->make('web.layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->yieldContent('content'); ?>

<div class="modal fade" tabindex="-1" role="dialog" id="myModal">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                <h4 id="modal_title" class="modal-title">Title</h4>
            </div>
            <div id="modal_body" class="modal-body">
                <p>One fine body&hellip;</p>
            </div>
            <div class="modal-footer">
                <div class=" pull-right">
                    <button type="button" class="btn btn-sm btn-default" data-dismiss="modal">Close</button>
                    &nbsp;
                </div>
                &nbsp;
                <div id="modalBtn" class="pull-right">&nbsp;</div>
                
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<?php echo $__env->make('web.layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script type="text/javascript">
    $(document).ready(function () {
        cartload();
    });

    function cartload() {
        var editurl = "<?php echo e(url('cart_load')); ?>";
        $.ajax({
            type: "GET",
            contentType: "application/json; charset=utf-8",
            url: editurl,
            data: '{"data":"' + "cart" + '"}',
            success: function (data) {
                $("#cartload").html(data);
            },
            error: function (xhr, status, error) {
                $('#cartload').html(xhr.responseText);
            }
        });
    }
</script>
<?php if(session()->has('message')): ?>
    <script type="text/javascript">
        setTimeout(function () {
            swal("Success", "<?php echo e(session()->get('message')); ?>", "success");
        }, 500);
    </script>
<?php endif; ?>
<?php if($errors->any()): ?>
    <script type="text/javascript">
        if ('<?php echo e($errors->first()); ?>' == 'Please login first') {
            ShowLoginSignup('signin');
        } else {
            setTimeout(function () {
                swal("Success", "<?php echo e($errors->first()); ?>", "success");
            }, 500);
        }

    </script>
<?php endif; ?>
</body>
</html>
