<?php $total = 0; $itemcount = 0; $gtotal = 0; $counter = 0; ?>
<?php if(count($cart) > 0): ?>
    <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <?php $total += $row->price * $row->qty;
        $counter++;
        $itemcount++;
        ?>
        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<span class="baskit_counter" id="baskit_counter"><?php echo e($counter); ?></span>
<i class="mdi mdi-basket menu_baskit_icon" id="baskit_block"></i>
<div class="card_menubox">
    <div class="header_popup">
        <div class="total_item_count">
            <span class="basic_icon mdi mdi-basket-fill"></span>
            <?php echo e($itemcount); ?> Item
        </div>
        <div class="total_item_amt pull-right">
            <span class="basic_icon mdi mdi-currency-inr"></span>
            <?php echo e($total); ?>

        </div>
    </div>
    <div class="card_menubox_containner style-scroll">
        <table class="table table-striped table_addcard">
            <tbody>
            <?php $total = 0; $gst = 0; $gtotal = 0; $sp = 0; ?>
            <?php if(count($cart)>0): ?>
                <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-left"><a class="cart_product_name"
                                                 title="<?php echo e($row->name); ?>"
                                                 href="#"><?php echo e(str_limit($row->name, 18)); ?></a></td>
                        <td class="text-center">x<?php echo e($row->qty); ?></td>
                        <td class="text-center"><i class="fa fa-inr"></i><?php echo e($row->price); ?></td>
                        <td class="text-right">
                            <a onclick="remove_item('<?php echo e($row->rowId); ?>')" class="mdi mdi-close-circle cart-delete"
                               data-toggle="tooltip" title="Remove"></a>
                        </td>
                    </tr>
                    <?php $total += $row->price * $row->qty;
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="cart_btn_box">
        <a class="btn btn-warning btn-sm" href="<?php echo e(url('mycart')); ?>">
            <span class="mdi mdi-basket basic_icon_margin"></span>View Cart
        </a>
        <a class="btn btn-success btn-sm pull-right" href="<?php echo e(url('checkout')); ?>">
            <span class="mdi mdi-cart basic_icon_margin"></span>Checkout
        </a>
    </div>
</div>
<script type="text/javascript">
    $(document).ready(function () {
        $('[data-toggle="tooltip"]').tooltip();
    });
    function remove_item(cart_item_id) {
        $.ajax({
            type: 'get',
            url: "<?php echo e(url('cart_delete')); ?>",
            data: {cart_item_id: cart_item_id},
            success: function (data) {
                $("#cartload").html(data);
                $('.card_menubox').addClass('show_card');

            },
            error: function (xhr, status, error) {
                $('#cartload').html(xhr.responseText);
            }
        });
        // promo_code

    }
</script>