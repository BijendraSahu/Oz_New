<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Categorymaster extends Model
{
    protected $table = 'category_master';
    public $timestamps = false;
}
