<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BlogCategoryRecord extends Model
{
    protected $table = 'blog_cat_record';
    public $timestamps = false;
}
