<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Stitches extends Model
{
    protected $table = 'stitching_prices';
    public $timestamps = false;
}
