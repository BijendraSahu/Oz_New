{{--<link rel="shortcut icon" type="images/png" href="{{url('images/favicon-tajtailors.png')}}"/>--}}
{{--<meta name="viewport" content="width=device-width,initial-scale=1">--}}
{{--<link rel="stylesheet" href="{{url('css/bootstrap.css')}}"/>--}}
{{--<link rel="stylesheet" href="{{url('css/bootstrap.min.css')}}"/>--}}
{{--<link rel="stylesheet" href="{{url('css/materialdesignicons.min.css')}}"/>--}}
{{--<link rel="stylesheet" href="{{url('css/flaticon.css')}}"/>--}}
{{--<link rel="stylesheet" href="{{url('css/frount.css')}}"/>--}}
{{--<link rel="stylesheet" href="{{url('css/media.css')}}"/>--}}
{{--<link rel="stylesheet" href="{{url('css/datepicker.css')}}"/>--}}
{{--<script src="{{url('js/jquery-3.2.1.min.js')}}"></script>--}}
{{--<script src="{{url('js/bootstrap.min.js')}}"></script>--}}
{{--<script src="{{url('js/Datepicker.js')}}"></script>--}}
{{--<script src="{{url('js/Global.js')}}"></script>--}}
{{--<script src="{{url('js/sweetalert.min.js')}}"></script>--}}
{{--<script src="{{url('js/login_validation.js')}}"></script>--}}
{{--<link href="https://fonts.googleapis.com/css?family=Open+Sans+Condensed:300" rel="stylesheet"/>--}}
<link rel="shortcut icon" type="images/png" href="images/oz-images/oz-fevicon.png"/>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="stylesheet" href="css/bootstrap.css" />
<link rel="stylesheet" href="css/bootstrap.min.css" />
<link rel="stylesheet" href="css/materialdesignicons.min.css" />
<link rel="stylesheet" href="css/flaticon.css" />
<link rel="stylesheet" href="css/frount.css" />
<link rel="stylesheet" href="css/media.css"/>
<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/Global.js"></script>
<link href="https://fonts.googleapis.com/css?family=Open+Sans+Condensed:300" rel="stylesheet" />
